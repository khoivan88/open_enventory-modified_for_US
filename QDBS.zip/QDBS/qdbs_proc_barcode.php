<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this m
  odule.
 */
require_once "lib_ktfuncs.php";
session_start();
if (!$_SESSION) {
	$_SESSION["qdbss"] = "Wrong starting page!";
	forwardTo();
	exit();
} else {
	$scale = $_SESSION["scale"];
	if ($_POST and ( $_POST["cbar"] == "00314152" or $_POST["cbar"] == "logout")) {
		$_SESSION["usrname"] = "";
		$_SESSION["pwd"] = "";
		$_SESSION["qdbss"] = "Logout successful";
		forwardTo();
		exit();
	}
	if ($_POST and ( $_POST["cbar"] == "00271820" or $_POST["cbar"] == "switch")) {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$_SESSION["mode"] = "borrow";
				$msg = "borrowing";
				break;
			case "borrow":
				$_SESSION["mode"] = "inv1";
				$msg = "inventarization";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		switch ($_SESSION["mult"]) {
			case "sin":
				$msg2 = "single";
				break;
			case "mult":
				$msg2 = "multiple";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	if ($_POST and ( $_POST["cbar"] == "00271813" or $_POST["cbar"] == "switch2")) {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$msg = "inventarization";
				break;
			case "borrow":
				$msg = "borrowing";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		switch ($_SESSION["mult"]) {
			case "sin":
				$_SESSION["mult"] = "mult";
				$msg2 = "multiple";
				break;
			case "mult":
				$_SESSION["mult"] = "sin";
				$msg2 = "single";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	$dbname = $_SESSION["dbname"];
	$pwd = $_SESSION["pwd"];
	$usrname = $_SESSION["usrname"];
	$conn = mysqli_connect("localhost", $usrname, $pwd, $dbname);
	if (mysqli_connect_errno()) {
		$_SESSION["qdbss"] = "Wrong username or password, please try again";
		forwardTo();
		exit();
	}
	if ($_POST and $_POST["mode"]) {
		$_SESSION["mode"] = $_POST["mode"];
	}
	if ($_POST and $_POST["mult"]) {
		$_SESSION["mult"] = $_POST["mult"];
	}
	if ($_SESSION["mult"] == "sin") {
		switch ($_SESSION["return"]) {
			case 0:
				$filter = "/2[0-9]{7}/";
				if (!preg_match($filter, $_POST["cbar"]) or readbar($_POST["cbar"]) == false) {
					$_SESSION["qdbss"] = "ERROR, wrong barcode type";
					mysqli_close($conn);
					forwardTo('qdbs.php');
					exit();
				}
				$cbar = $_POST["cbar"];
				$_SESSION["cbar"] = $cbar;
				break;
			case 1:
			case 2:
				$cbar = $_SESSION["cbar"];
				break;
			default:
				$_SESSION["qdbss"] = "A strange error has occurred";
				mysqli_close($conn);
				forwardTo('qdbs.php');
				exit();
		}
		switch ($_SESSION["return"]) {
			case 0:
			case 1:
				$csid = readbar($cbar);
				$sql0 = "SELECT * FROM chemical_storage WHERE chemical_storage_id = " . fixNull($csid) . " AND disposed_when IS NULL;";
				$res = mysqli_query($conn, $sql0);
				$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
				if ($res2 == array()) {
					$_SESSION["qdbss"] = "The package was not found in the database. Maybe it was deleted...";
					mysqli_close($conn);
					forwardTo('qdbs.php');
					exit();
				}
				$sql1 = "SELECT * FROM molecule WHERE molecule_id = " . fixNull($res2["molecule_id"]) . ";";
				$res = mysqli_query($conn, $sql1);
				$res3 = mysqli_fetch_array($res, MYSQLI_ASSOC);
				$molecule = array_merge($res2, $res3);
				$sql2 = "SELECT molecule_name FROM molecule_names WHERE molecule_id = " . fixNull($res2["molecule_id"]) . " AND is_standard = 1" . ";";
				$res = mysqli_query($conn, $sql2);
				$res3 = mysqli_fetch_array($res, MYSQLI_ASSOC);
				$molecule["name"] = $res3["molecule_name"];
				if ($res2["storage_id"]) {
					$sql3 = "SELECT storage_name FROM storage WHERE storage_id = " . fixNull($res2["storage_id"]) . ";";
					$res = mysqli_query($conn, $sql3);
					$res3 = mysqli_fetch_array($res, MYSQLI_ASSOC);
					$molecule["storage_name"] = $res3["storage_name"];
				} else {
					$molecule["storage_name"] = "NOT SET";
				}
				if ($molecule["borrowed_by_person_id"]) {
					$sql4 = "SELECT username,last_name,first_name FROM person WHERE person_id =" . fixNull($molecule["borrowed_by_person_id"]) . ";";
					$res = mysqli_query($conn, $sql4);
					$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
					$molecule = array_merge($res2, $molecule);
				}
				$_SESSION["molecule"] = $molecule;
				break;
			case 2:
				$molecule = $_SESSION["molecule"];
				break;
			default:
				$_SESSION["qdbss"] = "A strange error has occurred";
				mysqli_close($conn);
				forwardTo('qdbs.php');
				exit();
		}
		if ($_SESSION["qdbss"] != "") {
			echo "<h1>" . $_SESSION["qdbss"] . "</h1>";
		}
		if ($_SESSION["mode"] == "borrow") {
			$name = "Person";
		} else {
			$name = "Storage";
		}
		echo "
<html>
<body>
<form action=\"qdbs_process_single.php\" method=\"post\">"
		. $name . " barcode<input type=\"text\" name=\"sbar\" autofocus><br>
<br>
<button id=\"go\">go!</button>
</form>
";
		$filter = "/svg height=\"(.*)\" width=\"(.*)\" view/";
		preg_match_all($filter, $molecule["svg_file"], $size);
		$oldheight = $size[1][0];
		$oldwidth = $size[2][0];
		$width = $oldwidth * $scale;
		$height = $oldheight * $scale;
		$replace = "height=\"" . $oldheight . "\" width=\"" . $oldwidth . "\"";
		$replacement = "height=\"" . $height . "\" width=\"" . $width . "\"";
		$pic = str_replace($replace, $replacement, $molecule["svg_file"]);
		if ($pic) {
			echo $pic . "<br>";
		} else {
			echo $molecule["svg_file"] . "<br>";
		}
		echo "Name = " . $molecule["name"] . "<br>";
		echo "CAS Nr.: " . $molecule["cas_nr"] . "<br>";
		echo "Empirical formula: " . $molecule["emp_formula"] . "<br>";
		echo "Bottle size = " . $molecule["amount"] . " " . $molecule["amount_unit"] . "<br>";
		echo "Amount = " . $molecule["actual_amount"] . " " . $molecule["amount_unit"] . "<br>";
		echo "Compartment = " . $molecule["compartment"] . "<br>";
		echo "<h2><b>Storage =" . $molecule["storage_name"] . "</b></h2>";
		if ($molecule["borrowed_by_person_id"]) {
			echo "<h2><b>Borrowed by: " . $molecule["username"] . " (" . $molecule["first_name"] . " " . $molecule["last_name"] . ")</b></h2></body></html>";
		} else {
			echo "</body></html>";
		}
	} else {
		if ($_SESSION["mode"] == "borrow") {
			$filter = "/91[0-9]{6}/";
			$name = "person";
		} else {
			$filter = "/92[0-9]{6}/";
			$name = "storage";
		}
		switch ($_SESSION["return"]) {
			case 0:
//an assignment barcode was scanned for the first time, no checks were made yet
				if (!preg_match($filter, $_POST["cbar"]) or readsbar($_POST["cbar"]) == false) {
					$_SESSION["qdbss"] = "ERROR, wrong " . $name . " barcode";
					mysqli_close($conn);
					forwardTo('qdbs.php');
					exit();
				} else {
					$sbar = $_POST["cbar"];
				}
				break;
			case 1:
			case 2:
			case 3:
				$sbar = $_SESSION["sbar"];
				break;
			default:
				$_SESSION["qdbss"] = "A strange error has occurred";
				mysqli_close($conn);
				forwardTo('qdbs.php');
				exit();
		}
		switch ($_SESSION["return"]) {
			case 0:
			case 1:
				$sid = readsbar($sbar);
				if ($_SESSION["mode"] == "borrow") {
					$sql0 = "SELECT person_id, last_name, first_name, username FROM person WHERE person_id =" . fixNull($sid) . ";";
					$res = mysqli_query($conn, $sql0);
					$person = mysqli_fetch_array($res, MYSQLI_ASSOC);
					if ($person and $person["person_id"] == $sid) {
						$_SESSION["person"] = $person;
					} else {
						$_SESSION["qdbss"] = "ERROR, wrong person barcode";
						mysqli_close($conn);
						forwardTo('qdbs.php');
						exit();
					}
				} else {
					$sql0 = "SELECT storage_name,storage_id FROM storage WHERE storage_id = " . fixNull($sid) . ";";
					$res = mysqli_query($conn, $sql0);
					$storage = mysqli_fetch_array($res, MYSQLI_ASSOC);
					if ($storage and $storage["storage_id"] == $sid) {
						$_SESSION["storage"] = $storage;
					} else {
						$_SESSION["qdbss"] = "ERROR, wrong storage barcode";
						mysqli_close($conn);
						forwardTo('qdbs.php');
						exit();
					}
				}
				break;
			case 2:
			case 3:
				if ($_SESSION["mode"] == "borrow") {
					$person = $_SESSION["person"];
				} else {
					$storage = $_SESSION["storage"];
				}
				break;
			default:
				$_SESSION["qdbss"] = "A strange error has occurred";
				mysqli_close($conn);
				forwardTo('qdbs.php');
				exit();
		}
		if ($_SESSION["mode"] == "borrow") {
			echo "<h1><h1><b><u>ATTENTION:</u></b> You are now in multiple assignment mode and are about to borrow packages to user " . $person["username"] . " (" . $person["first_name"] . " " . $person["last_name"] . ")!</h1>";
			$name = "borrowed";
		} else {
			echo "<h1><b><u>ATTENTION:</u></b> You are now in multiple assignment mode and are about to put packages into the storage " . $storage["storage_name"] . "!</h1>";
			$name = "moved";
		}
		if ($_SESSION["qdbss"] != "") {
			echo "<h1>" . $_SESSION["qdbss"] . "</h1>";
		}
		echo "
<html>
<body>
<form action=\"qdbs_process_multiple.php\" method=\"post\">
Package barcode<input type=\"text\" name=\"cbar\" autofocus><br>
<br>
<button id=\"go\">go!</button>
</form>
";
		if ($_SESSION["return"] == 2) {
			$molecule = $_SESSION["molecule"];
			if ($molecule) {
				echo "Info about the package you just " . $name . ":<br>";
				$filter = "/svg height=\"(.*)\" width=\"(.*)\" view/";
				preg_match_all($filter, $molecule["svg_file"], $size);
				$oldheight = $size[1][0];
				$oldwidth = $size[2][0];
				$width = $oldwidth * $scale;
				$height = $oldheight * $scale;
				$replace = "height=\"" . $oldheight . "\" width=\"" . $oldwidth . "\"";
				$replacement = "height=\"" . $height . "\" width=\"" . $width . "\"";
				$pic = str_replace($replace, $replacement, $molecule["svg_file"]);
				if ($pic) {
					echo $pic . "<br>";
				} else {
					echo $molecule["svg_file"] . "<br>";
				}
				echo "Name = " . $molecule["name"] . "<br>";
				echo "CAS Nr.: " . $molecule["cas_nr"] . "<br>";
				echo "Empirical formula: " . $molecule["emp_formula"] . "<br>";
				echo "Bottle size = " . $molecule["amount"] . " " . $molecule["amount_unit"] . "<br>";
				echo "Amount = " . $molecule["actual_amount"] . " " . $molecule["amount_unit"] . "<br>";
				echo "Compartment = " . $molecule["compartment"] . "<br>";
				echo "<h2><b>Storage =" . $molecule["storage_name"] . "</b></h2>";
				if ($molecule["borrowed_by_person_id"]) {
					if ($_SESSION["mode"] == "inv1") {
						$sql4 = "SELECT username,last_name,first_name FROM person WHERE person_id =" . fixNull($molecule["borrowed_by_person_id"]) . ";";
						$res = mysqli_query($conn, $sql4);
						$person = mysqli_fetch_array($res, MYSQLI_ASSOC);
					}
					echo "<h2><b>Borrowed by: " . $person["username"] . " (" . $person["first_name"] . " " . $person["last_name"] . ")</b></h2></body></html>";
				} else {
					echo "</body></html>";
				}
			}
		} else {
			echo"</body></html>";
		}
	}
	mysqli_close($conn);
}
?>
