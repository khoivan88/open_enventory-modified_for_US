<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this m
  odule.
 */
require_once "lib_ktfuncs.php";
session_start();
if (!$_SESSION) {
	$_SESSION["qdbss"] = "Wrong starting page!";
	forwardTo();
	exit();
} else {
	$_SESSION["return"] = 0;
	$_SESSION["cbar"] = "";
	$_SESSION["sbar"] = "";
	unset($_SESSION["molecule"]);
	unset($_SESSION["storage"]);
	unset($_SESSION["person"]);
	if ($_SESSION["qdbss"]) {
		echo "<h1>" . $_SESSION["qdbss"] . "</h1>";
	}
	$dbname = $_SESSION["dbname"];
	$pwd = $_SESSION["pwd"];
	$usrname = $_SESSION["usrname"];
	$conn = mysql_connect("localhost", $usrname, $pwd);
	if (!$conn) {
		$_SESSION["qdbss"] = "Wrong username or password, please try again";
		forwardTo();
		exit();
	}
	$_SESSION["qdbss"] = "";
	echo "
<html>
<body>
<form action=\"qdbs_proc_barcode.php\" method=\"post\">
Package/storage barcode<input type=\"text\" name=\"cbar\" autofocus><br>
<br>";
	switch ($_SESSION["mode"]) {
		case "inv1":
			echo "<input type=\"radio\" name=\"mode\" value=\"inv1\" checked>Inventarization mode
<input type=\"radio\" name=\"mode\" value=\"borrow\">Borrowing mode<br>";
			break;
		case "borrow":
			echo "<input type=\"radio\" name=\"mode\" value=\"inv1\">Inventarization mode
<input type=\"radio\" name=\"mode\" value=\"borrow\" checked>Borrowing mode<br>";
			break;
		default:
			echo "not implemented yet, sorry";
			exit();
	}
	switch ($_SESSION["mult"]) {
		case "sin":
			echo "<input type=\"radio\" name=\"mult\" value=\"sin\" checked>Single assignment
<input type=\"radio\" name=\"mult\" value=\"mult\">Multiple assignment<br>";
			break;
		case "mult":
			echo "<input type=\"radio\" name=\"mult\" value=\"sin\">Single assignment
<input type=\"radio\" name=\"mult\" value=\"mult\" checked>Multiple assignment<br>";
			break;
		default:
			echo "not implemented yet, sorry";
			exit();
	}
	echo"
<button id=\"go\">go!</button>
</form>
</body>
</html>
";
}
?>
