<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this m
  odule.
 */
require_once "lib_ktfuncs.php";
session_start();
if (!$_SESSION) {
	$_SESSION["qdbss"] = "Wrong starting page!";
	forwardTo();
	exit();
} else {
	if ($_POST["cbar"] == "00314152" or $_POST["cbar"] == "logout") {
		$_SESSION["usrname"] = "";
		$_SESSION["pwd"] = "";
		$_SESSION["qdbss"] = "Logout succesful";
		forwardTo();
		exit();
	}
	if ($_POST["cbar"] == "00271820" or $_POST["cbar"] == "switch") {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$_SESSION["mode"] = "borrow";
				$msg = "borrowing";
				break;
			case "borrow":
				$_SESSION["mode"] = "inv1";
				$msg = "inventarization";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$msg2 = "multiple";
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	if ($_POST["cbar"] == "00271813" or $_POST["cbar"] == "switch2") {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$msg = "inventarization";
				break;
			case "borrow":
				$msg = "borrowing";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$_SESSION["mult"] = "sin";
		$msg2 = "single";
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	$dbname = $_SESSION["dbname"];
	$pwd = $_SESSION["pwd"];
	$usrname = $_SESSION["usrname"];
	if ($_SESSION["mode"] == "borrow") {
		$old = $_SESSION["person"];
	} else {
		$old = $_SESSION["storage"];
	}
	$filter = "/2[0-9]{7}/";
	if ($_SESSION["mode"] == "borrow") {
		$filter2 = "/91[0-9]{6}/";
	} else {
		$filter2 = "/92[0-9]{6}/";
	}
	if (!preg_match($filter, $_POST["cbar"]) or readbar($_POST["cbar"]) == false) {
		if (!preg_match($filter2, $_POST["cbar"]) or readsbar($_POST["cbar"]) == false) {
			$_SESSION["qdbss"] = "ERROR, wrong barcode type, please try again";
			$_SESSION["return"] = 3;
			forwardTo('qdbs_proc_barcode.php');
			exit();
		} else {
			$_SESSION["sbar"] = $_POST["cbar"];
			$_SESSION["return"] = 1;
			$_SESSION["qdbss"] = "";
			forwardTo('qdbs_proc_barcode.php');
			exit();
		}
	}
	$csid = readbar($_POST["cbar"]);
	$csupdateres = csupdate($old, $csid, $_SESSION["mode"], $_SESSION["mult"], $_SESSION["usrdata"]);
	if ($csupdateres["status"] == "error") {
		$_SESSION["return"] = 3;
		$_SESSION["qdbss"] = $csupdateres["result"];
	} else {
		$_SESSION["return"] = 2;
		$_SESSION["qdbss"] = $csupdateres["status"];
		$_SESSION["molecule"] = $csupdateres["result"];
	}
	forwardTo('qdbs_proc_barcode.php');
	exit();
}
?>
