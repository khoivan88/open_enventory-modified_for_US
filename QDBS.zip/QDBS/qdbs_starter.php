<?php

/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this m
  odule.
 */
require_once "lib_ktfuncs.php";
session_start();
if (!$_POST) {
	$_SESSION["qdbss"] = "Wrong starting page!";
	forwardTo();
	exit();
} else {
	$usrname = $_POST["usrname"];
	$pwd = $_POST["pwd"];
	$dbname = $_POST["dbname"];
	$conn = mysqli_connect("localhost", $usrname, $pwd, $dbname);
	if (!mysqli_connect_errno()) {
		$sql0 = "SELECT first_name, last_name, person_id, username FROM person WHERE username= " . fixStr($usrname) . ";";
		$res = mysqli_query($conn, $sql0);
		$person = mysqli_fetch_array($res, MYSQLI_ASSOC);
		if ($person["username"] != $usrname) {
			$_SESSION["qdbss"] = "Your account seems to be damaged. Please use another account!";
			mysqli_close($conn);
			$_SESSION["usrname"] = "";
			$_SESSION["pwd"] = "";
			$_SESSION["dbname"] = "";
			forwardTo();
			exit();
		} else {
			mysqli_close($conn);
			$_SESSION["usrname"] = $usrname;
			$_SESSION["pwd"] = $pwd;
			$_SESSION["dbname"] = $dbname;
			$_SESSION["usrdata"] = $person;
			$_SESSION["usrdata"]["pwd"] = $_SESSION["pwd"];
			$_SESSION["usrdata"]["dbname"] = $_SESSION["dbname"];
			$_SESSION["scale"] = $_POST["scale"];
			$_SESSION["qdbss"] = "Hello, " . $usrname;
			$_SESSION["mode"] = "inv1";
			$_SESSION["mult"] = "sin";
			$_SESSION["return"] = 0;
			forwardTo('qdbs.php');
		}
	} else {
		$_SESSION["qdbss"] = "Wrong username or password, please try again";
		forwardTo();
	}
}
?>
