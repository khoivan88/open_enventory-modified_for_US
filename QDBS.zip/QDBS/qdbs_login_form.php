<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this m
  odule.
 */
require_once "lib_ktfuncs.php";
session_start();
if ($_SESSION and $_SESSION["qdbss"]) {
	echo "<h1>" . $_SESSION["qdbss"] . "</h1>";
	if ($_SESSION["qdbss"] != "Logout succesful") {
		session_unset();
		session_destroy();
	}
} else {
	echo "<h1>Welcome</h1>";
}
if ($_SESSION) {
	if ($_SESSION and $_SESSION["dbname"]) {
		$dbname = $_SESSION["dbname"];
	} else {
		$dbname = "JFH_inventory";
	}
	if ($_SESSION and $_SESSION["scale"] and $_SESSION["scale"] > 0) {
		$scale = $_SESSION["scale"];
	} else {
		$scale = 2;
	}
//if($_SESSION){
	session_unset();
	session_destroy();
//}
} else {
	$dbname = "JFH_inventory";
	$scale = 2;
}
echo "
<html>
<body>
<h1>
<form action=\" qdbs_starter.php\" method=\"post\">
username &nbsp; &nbsp; &nbsp;<input type=\"text\" name=\"usrname\" autofocus><br>
password &nbsp; &nbsp; &nbsp;<input type=\"password\" name=\"pwd\"></input><br>
database &nbsp; &nbsp; &nbsp;<input type=\"text\" name=\"dbname\" value=" . $dbname . "></input><br>
molecular structure scale &nbsp; &nbsp; &nbsp;<input type=\"text\" name=\"scale\" value=" . $scale . "></input><br>
<button id=\"go\">Login!</button>
</form>
</h1>
</body>
</html>
";
?>
