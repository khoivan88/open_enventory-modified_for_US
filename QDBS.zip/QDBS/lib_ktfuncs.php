<?php

function readbar($bar) {
	$bararr = str_split($bar);
	$res = 0;
	$check = 3 * $bararr[0];
	for ($i = 1; $i < 7; $i++) {
		$res = $res + pow(10, (6 - $i)) * $bararr[$i];
		$check = $check + pow(3, (($i + 1) % 2)) * $bararr[$i];
	}
	if (($bararr[$i] + $check) % 10 != 0) {
		return false;
	} else {
		return $res;
	}
}

function readsbar($bar) {
	$bararr = str_split($bar);
	$res = 0;
	$check = 3 * $bararr[0] + $bararr[1];
	for ($i = 2; $i < 7; $i++) {
		$res = $res + pow(10, (6 - $i)) * $bararr[$i];
		$check = $check + pow(3, (($i + 1) % 2)) * $bararr[$i];
	}
	if (($bararr[$i] + $check) % 10 != 0) {
		return false;
	} else {
		return $res;
	}
}

function csupdate($old, $new, $mode, $mult, $user) {
	$csupdateres = array();
	$conn = mysqli_connect("localhost", $user["username"], $user["pwd"], $user["dbname"]);
	if (mysqli_connect_errno()) {
		$csupdateres["result"] = "ERROR: " . mysqli_connect_error();
		$csupdateres["status"] = "error";
	} else {
		switch ($mult) {
			case "sin":
				$molecule = $old;
				switch ($mode) {
					case "borrow":
						$sql0 = "SELECT person_id, last_name, first_name, username FROM person WHERE person_id ='" . $new . "';";
						$res = mysqli_query($conn, $sql0);
						$person = mysqli_fetch_array($res, MYSQLI_ASSOC);
						if ($person != array()) {
							if ($molecule["borrowed_by_person_id"] == $person["person_id"]) {
								$history_new = " " . $person["first_name"] . " " . $person["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . ") " . $molecule["amount_unit"] . " returned.";
								$sql3 = "UPDATE chemical_storage SET borrowed_by_db_id=NULL, borrowed_when=NULL, borrowed_by_person_id=NULL,history="
									."CONCAT(history,'\n',NOW()," . fixStr($history_new) . ") WHERE chemical_storage_id = " . fixNull($molecule["chemical_storage_id"]) . ";";
								$res = mysqli_query($conn, $sql3);
								if (mysqli_error($conn)) {
									$csupdateres["result"] = "ERROR: " . mysqli_error($conn);
									$csupdateres["status"] = "error";
								} else {
									$csupdateres["status"] = $molecule["name"] . " was returned!";
									$molecule["borrowed_by_person_id"] = "";
									$molecule["borrowed_by_db_id"] = "";
									$molecule["borrowed_when"] = "";
									$csupdateres["result"] = $molecule;
								}
							} else {
								$history_new = " " . $person["first_name"] . " " . $person["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . ") " . $molecule["amount_unit"] . " borrowed.";
								$sql3 = "UPDATE chemical_storage SET borrowed_by_db_id=-1, borrowed_when=NOW(), borrowed_by_person_id=" . fixNull($person["person_id"]) . ",history="
									."CONCAT(history,'\n',NOW()," . fixStr($history_new) . ") WHERE chemical_storage_id = " . fixNull($molecule["chemical_storage_id"]) . ";";
								$res = mysqli_query($conn, $sql3);
								if (mysqli_error($conn)) {
									$csupdateres["result"] = "ERROR: " . mysqli_error($conn);
									$csupdateres["status"] = "error";
								} else {
									$csupdateres["status"] = $molecule["name"] . " was borrowed by " . $person["first_name"] . " " . $person["last_name"] . " also known as " . $person["username"];
									$molecule["borrowed_by_person_id"] = $person["person_id"];
									$molecule["borrowed_by_db_id"] = "-1";
									$molecule["borrowed_when"] = date("Y-m-d H:i:s");
									$csupdateres["result"] = $molecule;
								}
							}
						} else {
							$csupdateres["status"] = "error";
							$csupdateres["result"] = "A person entry with this id can not be found in the database. Maybe it was deleted ...";
						}
						break;
					case "inv1":
						$sql0 = "SELECT storage_name,storage_id FROM storage WHERE storage_id = " . fixNull($new) . ";";
						$res = mysqli_query($conn, $sql0);
						$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
						if ($res2 != array()) {
							$history_new = " " . $user["first_name"] . " " . $user["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . " => " . $molecule["actual_amount"] . ") " . $molecule["amount_unit"];
							if ($res2["storage_name"] and $molecule["storage_name"]) {
								if ($res2["storage_name"] != $molecule["storage_name"]) {
									$history_new.="\n(STORAGE: " . $molecule["storage_name"] . " => " . $res2["storage_name"] . ")";
								}
							} else {
								if ($molecule["storage_name"]) {
									$history_new.="\n(STORAGE: " . $molecule["storage_name"] . " => NOT SET";
								} else {
									if ($res2["storage_name"]) {
										$history_new.="\n(STORAGE: NOT SET => " . $res2["storage_name"] . ")";
									}
								}
							}
							$sql1 = "UPDATE chemical_storage SET storage_id = " . fixNull($res2["storage_id"]) . ", inventory_check_by=" . fixStr($user["username"]) . ", "
									."inventory_check_when = NOW(), history=CONCAT(history,'\n',NOW()," . fixStr($history_new) . ") WHERE chemical_storage_id = " 
									. fixNull($molecule["chemical_storage_id"]) . ";";
							$res = mysqli_query($conn, $sql1);
							if (mysqli_error($conn)) {
								$csupdateres["result"] = "ERROR:" . mysqli_error($conn);
								$csupdateres["status"] = "error";
							} else {
								$molecule["storage_id"] = $res2["storage_id"];
								$molecule["storage_id"] = $res2["storage_name"];
								$molecule["inventory_check_by"] = $user["username"];
								$molecule["inventory_check_when"] = date("Y-m-d H:i:s");
								$csupdateres["result"] = $molecule;
								$csupdateres["status"] = $molecule["name"] . " was moved to " . $res2["storage_name"] . "!";
							}
						} else {
							$csupdateres["status"] = "error";
							$csupdateres["result"] = "A storage with this id can not be found in the database. Maybe it was deleted ...";
						}
						break;
					default:
						$csupdateres["status"] = "error";
						$csupdateres["result"] = "Not implemented yet ...";
				}
				break;
			case "mult":
//get info about the molecule
				$sql0 = "SELECT * FROM chemical_storage WHERE chemical_storage_id = " . fixNull($new) . " AND disposed_when IS NULL;";
				$res = mysqli_query($conn, $sql0);
				if ($res) {
					$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
					if ($res2) {
						$sql1 = "SELECT * FROM molecule WHERE molecule_id = " . fixNull($res2["molecule_id"]) . ";";
						$res = mysqli_query($conn, $sql1);
						$res3 = mysqli_fetch_array($res, MYSQLI_ASSOC);
						$molecule = array_merge($res2, $res3);
						$sql2 = "SELECT molecule_name FROM molecule_names WHERE molecule_id = " . fixNull($res2["molecule_id"]) . " AND is_standard = 1" . ";";
						$res = mysqli_query($conn, $sql2);
						$res3 = mysqli_fetch_array($res, MYSQLI_ASSOC);
						$molecule["name"] = $res3["molecule_name"];
						if ($molecule["borrowed_by_person_id"]) {
							$sql4 = "SELECT username,last_name,first_name FROM person WHERE person_id =" . fixNull($molecule["borrowed_by_person_id"]) . ";";
							$res = mysqli_query($conn, $sql4);
							$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
							$molecule = array_merge($res2, $molecule);
						}
						if ($molecule["storage_id"]) {
							$sql = "SELECT storage_name FROM storage WHERE storage_id = " . fixNull($molecule["storage_id"]) . ";";
							$res = mysqli_query($conn, $sql);
							$res2 = mysqli_fetch_array($res, MYSQLI_ASSOC);
							$molecule["storage_name"] = $res2["storage_name"];
						} else {
							$molecule["storage_name"] = "NOT SET";
						}
						switch ($mode) {
							case "borrow":
								$person = $old;
								if ($molecule["borrowed_by_person_id"] == $person["person_id"]) {
									$history_new = " " . $person["first_name"] . " " . $person["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . ") " . $molecule["amount_unit"] . " returned.";
									$sql3 = "UPDATE chemical_storage SET borrowed_by_db_id=NULL, borrowed_when=NULL, borrowed_by_person_id=NULL,history=CONCAT(history,'\n',NOW()," 
										. fixStr($history_new) . ") WHERE chemical_storage_id = " . fixNull($molecule["chemical_storage_id"]) . ";";
									$res = mysqli_query($conn, $sql3);
									if (mysqli_error($conn)) {
										$csupdateres["status"] = "error";
										$csupdateres["result"] = "ERROR:" . mysqli_error($conn);
									} else {
										$csupdateres["status"] = $molecule["name"] . " was returned!";
									}
									$molecule["borrowed_by_person_id"] = false;
								} else {
									$history_new = " " . $person["first_name"] . " " . $person["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . ") " . $molecule["amount_unit"] . " borrowed.";
									$sql3 = "UPDATE chemical_storage SET borrowed_by_db_id=-1, borrowed_when=NOW(), borrowed_by_person_id=" . fixNull($person["person_id"]) 
										. ",history=CONCAT(history,'\n',NOW()," . fixStr($history_new) . ") WHERE chemical_storage_id = " . fixNull($molecule["chemical_storage_id"]) . ";";
									$res = mysqli_query($conn, $sql3);
									if (mysqli_error($conn)) {
										$csupdateres["status"] = "error";
										$csupdateres["result"] = "ERROR:" . mysqli_error($conn);
									} else {
										$csupdateres["status"] = $molecule["name"] . " was borrowed by " . $person["first_name"] . " " . $person["last_name"] . " also known as " . $person["username"];
									}
									$molecule["borrowed_by_person_id"] = $person["person_id"];
									$molecule["borrowed_by_db_id"] = "-1";
									$molecule["borrowed_when"] = date("Y-m-d H:i:s");
								}
								break;
							case "inv1":
								$storage = $old;
								$history_new = " " . $user["first_name"] . " " . $user["last_name"] . ": " . $molecule["name"] . " " . $molecule["amount"] . " (" . $molecule["actual_amount"] . " => " . $molecule["actual_amount"] . ") " . $molecule["amount_unit"];
								if ($storage["storage_name"] and $molecule["storage_name"]) {
									if ($storage["storage_name"] != $molecule["storage_name"]) {
										$history_new.="\n(STORAGE: " . $molecule["storage_name"] . " => " . $storage["storage_name"] . ")";
									}
								} else {
									if ($molecule["storage_name"]) {
										$history_new.="\n(STORAGE: " . $molecule["storage_name"] . " => NOT SET";
									} else {
										if ($storage["storage_name"]) {
											$history_new.="\n(STORAGE: NOT SET => " . $storage["storage_name"] . ")";
										}
									}
								}
								$sql3 = "UPDATE chemical_storage SET storage_id = " . fixNull($storage["storage_id"]) . ", inventory_check_by=" . fixStr($user["username"]) 
									. ", inventory_check_when = NOW(), history=CONCAT(history,'\n',NOW()," . fixStr($history_new) . ") WHERE chemical_storage_id = " 
									. fixNull($molecule["chemical_storage_id"]) . ";";
								$res = mysqli_query($conn, $sql3);
								if (mysqli_error($conn)) {
									$csupdateres["status"] = "error";
									$csupdateres["result"] = "ERROR:" . mysqli_error($conn);
								} else {
									$csupdateres["status"] = $molecule["name"] . " was moved to " . $storage["storage_name"] . "!";
								}
								$molecule = array_merge($molecule, $storage);
								$molecule["inventory_check_by"] = $user["username"];
								$molecule["inventory_check_when"] = date("Y-m-d H:i:s");
								break;
							default:
								$csupdateres["status"] = "error";
								$csupdateres["result"] = "Not implemented yet ...";
						}
					} else {
						$csupdateres["status"] = "error";
						$csupdateres["result"] = "ERROR: No database entry for this package was found. Maybe it was deleted...!";
					}
				} else {
					$csupdateres["status"] = "error";
					$csupdateres["result"] = "ERROR: " . mysqli_error($conn);
				}
				if ($csupdateres["status"] != "error") {
					$csupdateres["result"] = $molecule;
				}
				break;
			default:
				$csupdateres["status"] = "error";
				$csupdateres["result"] = "Not implemented yet ...";
		}
	}
	mysqli_close($conn);
	return $csupdateres;
}

function forwardTo($url="qdbs_login_form.php") {
	echo "<html>
<script type=\"text/javascript\">
        window.open('$url','_self')
    </script>
</html>";
}

// copied from OE by FR 151108
function fixStr($str) {
	return "\"".addslashes($str)."\"";
}
function fixNull($str) {
	if (strpos($str,",")!==FALSE && strpos($str,".")===FALSE) { // german style
		$str=str_replace(",",".",$str);
	}
	if (is_bool($str)) {
		return $str?"TRUE":"FALSE";
	}
	return ($str!=="" && is_numeric($str)?$str:"NULL");
}

?>
