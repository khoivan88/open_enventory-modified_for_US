<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
/*
  This module was written by Konstantin Troshin @ UC Berkeley. It is FREE to use. To my best knowledge, it works flawless, but I will take ABSOLUTELY NO RESPONSIBILITY for any loss or damaging of data that can result from the use of this module.
 */
require_once "lib_ktfuncs.php";
session_start();
if (!$_SESSION) {
	$_SESSION["qdbss"] = "Wrong starting page!";
	forwardTo();
	exit();
} else {
	$dbname = $_SESSION["dbname"];
	$pwd = $_SESSION["pwd"];
	$usrname = $_SESSION["usrname"];
	$molecule = $_SESSION["molecule"];
	if ($_POST["sbar"] == "00314152" or $_POST["sbar"] == "logout") {
		$_SESSION["usrname"] = "";
		$_SESSION["pwd"] = "";
		$_SESSION["qdbss"] = "Logout succesful";
		mysqli_close($conn);
		forwardTo();
		exit();
	}
	if ($_POST["sbar"] == "00271820" or $_POST["sbar"] == "switch") {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$_SESSION["mode"] = "borrow";
				$msg = "borrowing";
				break;
			case "borrow":
				$_SESSION["mode"] = "inv1";
				$msg = "inventarization";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$msg2 = "single";
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	if ($_POST["sbar"] == "00271813" or $_POST["sbar"] == "switch2") {
		switch ($_SESSION["mode"]) {
			case "inv1":
				$msg = "inventarization";
				break;
			case "borrow":
				$msg = "borrowing";
				break;
			default:
				echo "not implemented yet";
				exit();
		}
		$_SESSION["mult"] = "mult";
		$msg2 = "multiple";
		$_SESSION["qdbss"] = "You are now in " . $msg2 . " assignment " . $msg . " mode!";
		forwardTo('qdbs.php');
		exit();
	}
	if ($_SESSION["mode"] == "inv1") {
		$filter = "/92[0-9]{6}/";
		$filter2 = "/2[0-9]{7}/";
		if (!preg_match($filter, $_POST["sbar"]) or readsbar($_POST["sbar"]) == false) {
			if (!preg_match($filter2, $_POST["sbar"]) or readbar($_POST["sbar"]) == false) {
				$_SESSION["qdbss"] = "ERROR, wrong storage barcode, please try again";
				$_SESSION["return"] = 2;
			} else {
				$_SESSION["cbar"] = $_POST["sbar"];
				$_SESSION["return"] = 1;
				$_SESSION["qdbss"] = "";
			}
			forwardTo('qdbs_proc_barcode.php');
			exit();
		} else {
			$sid = readsbar($_POST["sbar"]);
			$csupdateres = csupdate($molecule, $sid, $_SESSION["mode"], $_SESSION["mult"], $_SESSION["usrdata"]);
			if ($csupdateres["status"] == "error") {
				$_SESSION["qdbss"] = $csupdateres["result"];
				$_SESSION["return"] = 2;
				forwardTo('qdbs_proc_barcode.php');
				exit();
			} else {
				$_SESSION["qdbss"] = $csupdateres["status"];
				$_SESSION["molecule"] = $csupdateres["result"];
				forwardTo('qdbs.php');
				exit();
			}
		}
	} else {
		$filter = "/91[0-9]{6}/";
		$filter2 = "/2[0-9]{7}/";
		if (!preg_match($filter, $_POST["sbar"]) or readsbar($_POST["sbar"]) == false) {
			if (!preg_match($filter2, $_POST["sbar"]) or readbar($_POST["sbar"]) == false) {
				$_SESSION["qdbss"] = "ERROR, wrong person barcode, please try again";
				$_SESSION["return"] = 2;
			} else {
				$_SESSION["return"] = 1;
				$_SESSION["cbar"] = $_POST["sbar"];
				$_SESSION["qdbss"] = "";
			}
			forwardTo('qdbs_proc_barcode.php');
			exit();
		} else {
			$pid = readsbar($_POST["sbar"]);
			$csupdateres = csupdate($molecule, $pid, $_SESSION["mode"], $_SESSION["mult"], $_SESSION["usrdata"]);
			if ($csupdateres["status"] == "error") {
				$_SESSION["qdbss"] = $csupdateres["result"];
				$_SESSION["return"] = 2;
				forwardTo('qdbs_proc_barcode.php');
				exit();
			} else {
				$_SESSION["qdbss"] = $csupdateres["status"];
				$_SESSION["molecule"] = $csupdateres["result"];
				forwardTo('qdbs.php');
				exit();
			}
		}
	}
}
?>
