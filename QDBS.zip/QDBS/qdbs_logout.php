<?php

header('Content-Type: application/download');
header('Content-Disposition: attachment; filename="QDBS_service_codes.pdf"');
header("Content-Length: " . filesize("QDBS_service_codes.pdf"));
$fp = fopen("QDBS_service_codes.pdf", "r");
fpassthru($fp);
fclose($fp);
?>
